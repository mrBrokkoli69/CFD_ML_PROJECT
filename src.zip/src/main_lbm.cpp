#include "io/case_io.h"
#include "io/results_io.h"
#include "lbm/lbm_core.h"
#include "lbm/lbm_runner.h"
#include "mask_editor/mask_loader.h"
#include "post/postprocessing.h"

#include <iostream>
#include <stdexcept>
#include <string>

int runSolverMode(int argc, char* argv[]) {
    try {
        SimulationConfig config;
        std::string maskPath;
        double characteristicLength = 20.0;

        initInteractiveConfig(config);
        applyCommandLineArgs(config, maskPath, characteristicLength, argc, argv);

        CasePaths casePaths = createCasePaths(maskPath);
        config.outputDir = casePaths.caseDir;

        ScopedCaseLogger logger(casePaths.logPath);

        Mask mask = loadMaskFromDat(maskPath);
        validateMaskSize(mask, config);

        printCaseHeader(casePaths, config, mask, maskPath, characteristicLength);

        SimulationResult result = runCase(config, mask);

        printSimulationSummary(result, config, characteristicLength);

        appendResultToCSV("./data/results/simulation_results.csv",
                          casePaths.caseName,
                          config,
                          result,
                          characteristicLength);

        return 0;
    }
    catch (const std::exception& e) {
        std::cerr << "ERROR: " << e.what() << std::endl;
        return 1;
    }
}
