#ifndef EDITOR_H
#define EDITOR_H

struct EditorMask {
    static const int WIDTH = 300;
    static const int HEIGHT = 80;

    bool cells[HEIGHT][WIDTH];

    EditorMask() {
        for (int y = 0; y < HEIGHT; y++) {
            for (int x = 0; x < WIDTH; x++) {
                cells[y][x] = false;
            }
        }
    }

    bool isSolid(int y, int x) const {
        if (y < 0 || y >= HEIGHT || x < 0 || x >= WIDTH) {
            return true;
        }
        return cells[y][x];
    }

    void setSolid(int y, int x, bool solid) {
        if (y >= 0 && y < HEIGHT && x >= 0 && x < WIDTH) {
            cells[y][x] = solid;
        }
    }
};

void drawMask(const EditorMask& mask, int cursorY, int cursorX);
int inputInt(const char* prompt);
int runEditorApp();

#endif
